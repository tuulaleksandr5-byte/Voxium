@echo off
cd /d "%~dp0"
set WGPU_BACKEND=vulkan
start "" Voxium.exe
