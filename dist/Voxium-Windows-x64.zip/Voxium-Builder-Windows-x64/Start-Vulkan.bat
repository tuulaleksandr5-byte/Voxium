@echo off
set WGPU_BACKEND=vulkan
start "" "%~dp0Voxium.exe"
