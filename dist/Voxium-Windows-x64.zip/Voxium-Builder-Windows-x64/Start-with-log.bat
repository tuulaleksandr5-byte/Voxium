@echo off
set RUST_LOG=info
"%~dp0Voxium.exe" > "%~dp0voxium-log.txt" 2>&1
